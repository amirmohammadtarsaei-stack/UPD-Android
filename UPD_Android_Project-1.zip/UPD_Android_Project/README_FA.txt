UPD Android - Bronze Edition

این پوشه سورس پروژه اندروید است، نه APK نهایی.
ساخت با JDK 17، Android SDK Platform 35 و Gradle 8.9 یا جدیدتر:
    gradle assembleDebug
خروجی:
    app/build/outputs/apk/debug/app-debug.apk

ساخت با گوشی از طریق GitHub Actions:
1) یک مخزن جدید و خالی در GitHub بساز.
2) فایل UPD_Android_Project.zip را در ریشه مخزن آپلود کن.
3) در مخزن، Add file > Create new file را بزن و مسیر زیر را وارد کن:
   .github/workflows/build-apk.yml
4) محتوای فایل UPD_build_apk_workflow.yml را در آن قرار بده و Commit کن.
5) تب Actions > Build UPD APK > Run workflow را انتخاب کن.
6) پس از پایان موفق، از Artifacts فایل upd-debug-apk را دانلود و استخراج کن.
7) app-debug.apk را نصب کن؛ در صورت درخواست، اجازه نصب از این منبع را فعال کن.

این نسخه اولیه برای آزمایش است. اطلاعات در حافظه محلی WebView نگهداری می‌شوند.
